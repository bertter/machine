# myNumber.py


import random

# select number
computer_number = random.randint(1, 100)

# is_same() function
def is_same(target, number):
    if target == number:
        result="Win"
    elif target > number:
        result="Low"
    else:
        result="High"
    return result

# start
print("hi\n I have thoutht of a number between 1 and 100.")

# collect the user's guess as an integer
guess = int(input("can you guess it?."))

# is_same() fucntion
higher_or_lower = is_same(computer_number, guess)

# run the game until the user is correct
while higher_or_lower != "Win":
    if higher_or_lower == "Low":
        guess = int(input("you are too low. try again."))
    else:
        guess = int(input("you are too high. try again."))

    higher_or_lower = is_same(computer_number, guess)

# end 
input("correct!\nWell done.\n\n\nPress Return to exit.")
