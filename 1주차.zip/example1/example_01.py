##### 00
from sklearn.ensemble import RandomForestClassifier
print("hello world")


##### 01
name = "Hong Gil Dong" #(1-1)
age = 18 #(1-2)
myskill = "bow"
i=0

skill = ["sword[pw97]","spear[pw99]","bow[pw96]","axe[pw98]"] #(2)

print ("1.name:", name) #(3)
print ("2.age:", age)

for each_item in skill: #(4)
    if(each_item.find(myskill) >= 0): #(5)
        print ("3.armed weapon:", each_item)
    i=i+1 #(6)
print ("list total:", i)


##### 02
import math
print("value of cos 30:", math.cos(30))


##### 03
name = "Hong Gil Dong"
age = 18
skill = ["sword[pw97]","spear[pw99]","bow[pw96]","axe[pw98]"]

def printItem(myskill): #(1)
    i=0
    print ("1.name:", name)
    print ("2.age:", age)

    for each_item in skill:
        if(each_item.find(myskill) >= 0):
            print ("3.armed weapon:", each_item)
        i=i+1
    print ("list total:", i)
    
printItem("sword") #(2)


#####04
name = "Hong Gil Dong"
age = 18
skill = ["sword[pw97]","spear[pw99]","bow[pw96]","axe[pw98]"]

class Item: #(1)
    def __init__(self, inskill): #(2)
        self.myskill = inskill
        
    def printItem(self): #(3)
        i=0
        print ("1.name:", name)
        print ("2.age:", age)

        for each_item in skill:
            if(each_item.find(self.myskill) >= 0): #(4)
                print ("3.armed weapon:", each_item)
            i=i+1
        print ("list total:", i)

item = Item("sword") #(5)
item.printItem() #(6)


#####05
from math import cos                #(1)
import math                         #(2)
import math as mt                   #(3)
print("value of cos1 30:", cos(30))      #(4)
print("value of sin1 30:", math.sin(30)) #(5)
print("value of sin2 30:", mt.sin(30))   #(6)


#####06
print("print string: [%s]" % "test")
print("print string: [%10s]" % "test") #(1)
print("print character: [%c]" % "t")
print("print character: [%5c]" % "t")  #(2)
print("print Integer: [%d]" % 17)      #(3)
print("print Float: [%f]" % 17)        #(4)
print("print Octal: [%o]" % 17)        #(5)
print("print Hexadecimal: [%x]" % 17)  #(6)


