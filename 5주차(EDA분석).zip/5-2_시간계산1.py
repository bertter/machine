Python 3.10.2 (tags/v3.10.2:a58ebcc, Jan 17 2022, 14:12:15) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
def times_tables(num):
	n=1
	while n <= 10:
		 print(n, "x", num, "=", n*num)
		 n = n+1
# 함수 정의 후 실행

times_tables(12)

1 x 12 = 12
2 x 12 = 24
3 x 12 = 36
4 x 12 = 48
5 x 12 = 60
6 x 12 = 72
7 x 12 = 84
8 x 12 = 96
9 x 12 = 108
10 x 12 = 120



def times_tables(how_far, num):
	n=1
	while n <= how_far:
		 print(n, "x", num, "=", n*num)
		 n = n+1

times_tables(12,17)

1 x 17 = 17
2 x 17 = 34
3 x 17 = 51
4 x 17 = 68
5 x 17 = 85
6 x 17 = 102
7 x 17 = 119
8 x 17 = 136
9 x 17 = 153
10 x 17 = 170
11 x 17 = 187
12 x 17 = 204
