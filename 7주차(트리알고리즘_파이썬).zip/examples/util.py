#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#ipydb 파일을 python 파일로 변경 : jupyter nbconvert --to script util.ipynb
#컬럼을 숫자형 문자열로 변환
def kor_to_numstr(in_df, padd_num, in_col):
    temp_df = in_df[in_col] #변환할 문자열에 해당하는 데이터 가져오기
    temp_df_i = temp_df.unique() #중복되는 컬럼명을 unique하게 뽑음
    temp_df_i.sort()
    i = 0
    in_col_no = []
    for x in temp_df_i:
        in_col_no.append(str(i).rjust(padd_num, '0')) #왼쪽에 0 padding
        i = i+1
    temp_df_i_list = temp_df_i.tolist() #convert ndarray to list
    zip_obj = zip(temp_df_i_list, in_col_no) #make dictionary (1)
    dic_obj = dict(zip_obj) #make dictionary (2)
    in_df[in_col] = in_df[in_col].apply(lambda x: dic_obj[x]) #convert kor name to number string
    
    return in_df

def makeup_cols(df_in, col_type):
    cols = list(df_in.columns)
    for tmp_col in cols:
        df_in[tmp_col] = df_in[tmp_col].astype(col_type)
    return df_in

def log(val, name='data'):
    print("*",name,":\n", val, "\n")